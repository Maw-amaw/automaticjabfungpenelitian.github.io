<nav class="navbar navbar-expand-lg navbar-dark " style="background-color:#19A149;">
    <div class="container">
        <a class="navbar-brand" href="../web/input.php">PENELITIHAN</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <div class="ml-auto">
                <a href="../controller/logout.php" class="btn btn-success mr-3">LOGOUT</a>
            </div>
        </div>
    </div>
</nav>
