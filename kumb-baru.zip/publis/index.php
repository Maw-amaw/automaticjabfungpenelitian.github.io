<?php
    include "../tambahan/css/cssboostrap.php";
    include "navbar/nav1.php";
?>

  <link rel="stylesheet" href="../tambahan/css/style.css">
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />


  <section>
    <div class="jumbotron-fluid" style="background-color:#19A149; text-align:center; color:white;">
    <br><br>
    <h1 class="display-4" style="font-family:arial;">KELOMPOK 1 <b style="font-weight:bold;">KUM-B</b></h1>
      <p class="lead">ini adalah hasil projek kelompok 1 yang berjudul atau bertemakan PENELITIHAN</p>
      <br>
    </div>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#19A149" fill-opacity="1" d="M0,192L20,181.3C40,171,80,149,120,160C160,171,200,213,240,229.3C280,245,320,235,360,197.3C400,160,440,96,480,80C520,64,560,96,600,112C640,128,680,128,720,128C760,128,800,128,840,144C880,160,920,192,960,197.3C1000,203,1040,181,1080,176C1120,171,1160,181,1200,186.7C1240,192,1280,192,1320,186.7C1360,181,1400,171,1420,165.3L1440,160L1440,0L1420,0C1400,0,1360,0,1320,0C1280,0,1240,0,1200,0C1160,0,1120,0,1080,0C1040,0,1000,0,960,0C920,0,880,0,840,0C800,0,760,0,720,0C680,0,640,0,600,0C560,0,520,0,480,0C440,0,400,0,360,0C320,0,280,0,240,0C200,0,160,0,120,0C80,0,40,0,20,0L0,0Z"></path></svg>
    <div class="jumbotron jumbotron-fluid">
      <center>
      
      <div class="container">
        <h3 style="text-align:center;" data-aos="fade-down"data-aos-delay =" 50 "
     data-aos-duration =" 1000 ">this is a member of group 1</h3>
        <br>
      <div class="row">
      <div class="col-sm-6">
        <div class="text-right">
          <div class="body">
            <blockquote class="blockquote mb-0">
              <p data-aos="fade-right"data-aos-offset="300"data-aos-easing="ease-in-sine">
              Haqqinia Nabila (2103191101) <br>
              Muhammad Dinan Faradha (2103191113) <br>
              Chrysna Ardy Putra Pratama(2103191115) <br>
              </p>
            </blockquote>
          </div>
        </div>
      </div>
    
      <div class="col-sm-6">
        <div class="text-left">
          <div class="body">
            <blockquote class="blockquote mb-0">
              <p data-aos="fade-left"data-aos-offset="350">
              Akhmad Mufti Ali wafa (2103191117) <br>
              Fatimatuz Zuhroh (2103191122) <br>
              Muhammad thoriqul haq(2103191126) <br>
              </p>
            </blockquote>
          </div>
        </div>
      </div>
  </div>
</div>
<br>
    </center>
  </div>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#19A149" fill-opacity="1" d="M0,192L20,181.3C40,171,80,149,120,160C160,171,200,213,240,229.3C280,245,320,235,360,197.3C400,160,440,96,480,80C520,64,560,96,600,112C640,128,680,128,720,128C760,128,800,128,840,144C880,160,920,192,960,197.3C1000,203,1040,181,1080,176C1120,171,1160,181,1200,186.7C1240,192,1280,192,1320,186.7C1360,181,1400,171,1420,165.3L1440,160L1440,320L1420,320C1400,320,1360,320,1320,320C1280,320,1240,320,1200,320C1160,320,1120,320,1080,320C1040,320,1000,320,960,320C920,320,880,320,840,320C800,320,760,320,720,320C680,320,640,320,600,320C560,320,520,320,480,320C440,320,400,320,360,320C320,320,280,320,240,320C200,320,160,320,120,320C80,320,40,320,20,320L0,320Z"></path></svg>
  </section> 
  
  <!-- about -->
  <section>

  </section>
  


  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
    AOS.init();
  </script>

<?php
include "../tambahan/js/jsboostrap.php";

?>
    